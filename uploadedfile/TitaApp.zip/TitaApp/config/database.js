// config/database.js

module.exports = {

    url: 'mongodb://admin:cmpe27201@oceanic.mongohq.com:10051/cmpe27201'

};